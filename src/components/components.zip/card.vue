<template>
<div class="card">
	<div v-show="!sendOk" ref="wrap">
		<div class="avatar">
			<div class="pic" ref="pic" @click="showBigImage(indexN)">
				<img :src="user.Url" width="100%">
			</div>
			<div class="message">
				<p class="name fontSize_20"><i class="icon_sex" :class="[user.Sex?'icon-man':'icon-wm']"></i>{{user.EmployeeName}}</p>
				<p class="birthday fontSize_14"><i class="bir_icon"></i>{{user.Birthday | $formatDate}}<i class="icon_comefrom"></i>{{user.Province}}<span v-show="user.Province != user.City">-{{user.City}}</span></p>
				<p class="job fontSize_14"><i class="icon_job"></i>{{user.Post}}</p>
				<p class="label fontSize_14"><i class="icon_label"></i><span class="label_item" v-for="item in user.hobbies">{{item.Name}}</span></p>
			</div>
		</div>
		<div class="desc">
			<p class="text fontSize_14">{{user.Description}}</p>
		</div>
		<div class="picWrap" v-show="picBig.length">
			<div class="img_box">
				<div class="img_lf" v-for="(item,index) in picBig" ref="imgLf" @click="showBigImage((index+1))"></div>
				<div class="img_rf">
					<div class="img_wrap" v-for="(item,index) in picSm" ref="imgRf" @click="showBigImage((index+2))">
					</div>
				</div>
			</div>
		</div>
		<div class="rating_wrap" v-show="user.Pushed">
			<h3 class="rating_title fontSize_12">{{ratings.length}}条评论</h3>
			<p class="noRating fontSize_16" v-show="!ratings.length">暂无评论</p>
			<ul class="ratings" v-show="ratings.length">
				<li class="rating" v-for="item in ratings">
					<div class="rating_avatar">
						<img :src="item.FaceUrl" height="100%">
					</div>
					<div class="rating_text">
						<div class="rating_name fontSize_16">
							{{item.CommentEmployeeName}}
						</div>
						<div class="rating_content fontSize_14">
							{{item.Content}}
						</div>
					</div>
				</li>
			</ul>
		</div>
		<div class="isSend" v-show="isSend == 1">
			<div class="send_wrap">
				<div class="send fontSize_16" @click="setData">发送</div>
			</div>
		</div>
		<div class="rating_box" v-show="isSend == 2">
			<div class="quick_rating">
				<span class="quick_text1 fontSize_14" @click="sendQuick1($event)" v-for="item in quickText" v-html="item"></span>
			</div>
			<div class="rating_input">
				<input class="input fontSize_16" type="text" placeholder="说点什么" v-model="ratingInput" @click="enterText">
				<span class="send_rating fontSize_16" @click="sendQuick2">发送</span>
			</div>
		</div>
	</div>
	<div class="loading" v-show="loadingShow">
		<div class="loading_wrap">
		</div>
	</div>
	<v-excessive v-show="sendOk" @setOk="setOk"></v-excessive>
</div>
</template>

<script>
import excessive from './excessive';
import {$loadImage} from '@/utils/loadImage.js';
import {$formatDate} from '@/utils/date.js';
export default {
	name: 'card',
	props: {
		userConfig: {
			type: Object
		}
	},
	data () {
		return {
			user: {},
			picBig: [],
			picSm: [],
			url: '',
			sendOk: false,
			indexN: 0,
			urlList: [],
			isSend: null,
			p: {},
			quickText: ['&#x1F339送上鲜花','&#x1F44F热烈欢迎','&#x1F4AA努力加油'],
			ratings: [],
			ratingInput: '',
			ratingName: '',
			ratingId: '',
			ratingFace: '',
			loadingShow: false
		}
	},
	created(){
		this.load();
		let employeeId = "";
		if (this.$route.query.employeeId) {
			employeeId = this.$route.query.employeeId;
			this.isSend = 2;
		}
		this.$http.get('/newtask/userinfo').then((response) => {
			response = response.body;
			this.ratingName = response.EmployeeName;
			this.ratingId = response.EmployeeID;
			if(response.FaceUrl == ''){
				this.ratingFace = require('../source/img/avatar.jpg');
			}else{
				this.ratingFace = response.FaceUrl;
			}
		});
		this.$http.get('/newtask/userinfo?employeeId='+ employeeId).then((response) => {
			response = response.body;
			this.user = response;

			if(this.user.FaceUrl == ''){
				this.user.FaceUrl = require('../source/img/avatar.jpg');
			}
			if(this.user.Pushed){
				this.isSend = 2;
			}else{
				this.isSend = 1;
			}

			// 请求评论
			this.$http.get('/newtask/cardCommentList?employeeId='+employeeId).then((response) => { 
				response = response.body;
				this.ratings = response.list;
				if(response.success){
					this.ratings.forEach((item) => {
						if(item.FaceUrl == ''){
							item.FaceUrl = require('../source/img/avatar.jpg');
						}
						item.Content = decodeURIComponent(item.Content);
					});
				}
			})
			this.$http.get('/newtask/review?employeeId='+employeeId).then((response) => {
				response = response.body.list;
				console.log(response)
				this.picBig = response.slice(0, 1);
				this.picSm = response.slice(1, 5);
				this.$nextTick(() => {
					this.url = this.user.Url;
					this.urlList.push(this.url);
					response.forEach((item) => {
						this.urlList.push(item.PicUrl);
					})
					let obj = this.$refs.pic;
					$loadImage(this.url, obj);
					$loadImage(this.picBig[0].PicUrl, this.$refs.imgLf[0])
					
					this.picSm.forEach((item, index) => {
						let obj = this.$refs.imgRf[index];
						let url = item.PicUrl;
						$loadImage(url, obj);
					})
				})
			})	
		});
	},
	watch: {
		'$route': 'load' 
	},
	methods: {
		load(){
			this.iosReturn();
			this.setRight();
			this.setTitle();
		},
		iosReturn(){
			let _self = this;
			dd.biz.navigation.setLeft({
				show: true,
				control: true,
				showIcon: true,
				text: '返回',
				onSuccess : function(result) {
					let back = _self.$route.query.back;
					if(_self.user.Pushed){
						if (back) {
							_self.$router.push({path: '/dictionary', query:{title: '乐助手', part: 'dictionary'}});
						} else {
							dd.biz.navigation.close({});
						}
					}else{
						dd.biz.navigation.close({});
					}
				},
				onFail : function(err) {}
			});
		},
		setRight(){
			let _self = this
			dd.biz.navigation.setRight({
				show: true,//控制按钮显示， true 显示， false 隐藏， 默认true
				control: true,//是否控制点击事件，true 控制，false 不控制， 默认false
				text: '编辑',//控制显示文本，空字符串表示显示默认文本
				onSuccess : function(result) {
					_self.$router.push({ path: '/changemsg'})
				},
				onFail : function(err) {}
			});
		},
		setTitle(){
			dd.biz.navigation.setTitle({
				title : '个人名片',
			});
		},
		showBigImage(index){
			let _self = this;
			let urlList = this.urlList;
			let str = urlList[index];
			dd.biz.util.previewImage({
				urls: urlList,//图片地址列表
				current: str,//当前显示的图片链接
				onSuccess : function(result) {
					/**/
				},
				onFail : function(err) {}
			})
		},
		setData(){
			let _self = this;
			dd.biz.contact.complexPicker({
				title:"选择",
				corpId: _self.userConfig.openId,
				multiple: true,
				limitTips: "超出了",
				maxUsers: 1000,
				appId: _self.userConfig.agentId,
				permissionType: "GLOBAL",
				responseUserOnly: true,
				onSuccess: function(result) {
					let deptlist = [];
					for (let i = 0; i < result.users.length; i++) {
						deptlist.push(result.users[i].emplId);
					}
					let num = 10;
					let user_id_list = deptlist;
					_self.$http.post('/tem/sendmsg222',{page: num, user_id_list: user_id_list},{emulateJSON: true,traditional: true}).then((response) => {
						response = response.body;
						if(response.code == 200){
							dd.device.notification.hidePreloader({
								onSuccess : function(result) {
									_self.sendOk = true;
									dd.biz.navigation.setRight({
										show: false,
										control: true,
									});
								},
								onFail : function(err) {}
							});
						} 
						if(response.code == 500){
							_self.sendOk = false
							dd.device.notification.alert({
								message: "发送失败，请重新发送",
								title: "提示",//可传空
								buttonName: "好的",
								onSuccess : function() {
									//onSuccess将在点击button之后回调
									/*回调*/
								},
								onFail : function(err) {}
							});
						}
					});
				},
				onFail : function(err) {}
			});
		},
		setOk(){
			this.sendOk = !this.sendOk;
		},
		sendQuick1(event){
			let data = new Date();
			let a = {};
			let obj = event.target;
			this.loadingShow = true;
			let tem = encodeURIComponent(obj.innerHTML);
			a.Content = obj.innerHTML;
			a.CommentEmployeeId = this.ratingId;
			a.CommentEmployeeName = this.ratingName;
			a.CommentTime = data;
			a.FaceUrl = this.ratingFace;
			this.$http.post('/newtask/cardComment',{content: tem, employeeId: this.user.EmployeeID},{emulateJSON: true}).then((response) => {
				response = response.body;
				if(response.success){
					this.loadingShow = false;
					this.ratings.push(a);
					this.$nextTick(() => {
						window.scrollTo(0,100000);
					})
				}
			})
		},
		sendQuick2(){
			if(this.ratingInput == ''){
				return
			}

			let data = new Date();
			let a = {};
			let tem = encodeURIComponent(this.ratingInput);
			a.Content = this.ratingInput;
			a.CommentEmployeeId = this.ratingId;
			a.CommentEmployeeName = this.ratingName;
			a.CommentTime = data;
			a.FaceUrl = this.ratingFace;
			this.loadingShow = true;

			this.$http.post('/newtask/cardComment',{content: tem, employeeId: this.user.EmployeeID},{emulateJSON: true}).then((response) => {
				response = response.body;
				if(response.success){
					this.loadingShow = false;
					this.ratings.push(a);
					this.ratingInput = '';
					this.$nextTick(() => {
						window.scrollTo(0,100000);
					});
				}
			});
		},
		enterText(){
			let u = navigator.userAgent;
			let isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
			let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端

			if(isAndroid){
				return
			}
			if(isiOS){
				let _self = this;
				this.isSend = null;
				dd.ui.input.plain({
					placeholder: '说点什么', //占位符
					text: _self.ratingInput, //默认填充文本
					onSuccess: function(data) {
						_self.isSend = 2;
						_self.ratingInput = data.draft;
						
						if(data.text){
							let dete = new Date();
							let a = {};
							let tem = encodeURIComponent(data.text);
							a.Content = data.text;
							a.CommentEmployeeId = _self.ratingId;
							a.CommentEmployeeName = _self.ratingName;
							a.CommentTime = data;
							a.FaceUrl = _self.ratingFace;
							_self.$http.post('/newtask/cardComment',{content: tem, employeeId: _self.user.EmployeeID},{emulateJSON: true}).then((response) => {
								response = response.body;
								if(response.success){
									_self.ratings.push(a);
									_self.ratingInput = '';
									_self.$nextTick(() => {
										window.scrollTo(0,100000);
									});
								}
							});
						}
					},
					onFail: function() {
					}
				});
			}
		}
	},
	filters: {
		$formatDate (time) {
			let data = new Date(time);
			return $formatDate(data, 'MM月dd日');
		}
	},
	components: {
		"v-excessive": excessive
	}
}
</script>

<style rel="stylesheet/less" lang="less" scoped>
@r:37.5rem;
.card{
	position: relative;
	width: 100%;
	height: 100%;
	background-color: #FFF;
	.avatar{
		position: relative;
		width: 100%;
		padding: 15/@r 15/@r 0 15/@r;
		box-sizing: border-box;
		min-height: 94/@r;
		max-height: 114/@r;
		.pic{
			float: left;
			width: 100/@r;
			height: 75/@r;
			border: 4px solid #FFFFFF;
			box-shadow: 0 2px 4px 0 rgba(0,0,0,0.10);
			box-sizing: border-box;
			overflow: hidden;
			margin-top: 10/@r;
		}
		.message{
			float: left;
			width: 230/@r;
			margin-left: 11/@r;
			.name{
				height: 28/@r;
				line-height: 28/@r;
				font-weight: 700;
				color: #222;
				.icon_sex{
					display: inline-block;
					vertical-align: top;
					width: 12/@r;
					height: 28/@r;
					margin-right: 7/@r;
					background-repeat: no-repeat;
					background-size: 100%;
					background-position: 0 6/@r;
				}
				.icon-man{
					background-image: url('../source/img/icon_man.svg');
				}
				.icon-wm{
					background-image: url('../source/img/icon_wm.svg');
				}
			}
			.birthday{
				line-height: 20/@r;
				height: 20/@r;
				color: #666;
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
				.bir_icon{
					display: inline-block;
					vertical-align: top;
					width: 14/@r;
					height: 20/@r;
					margin-right: 5/@r;
					background-image: url('../source/img/icon_birth.svg');
					background-repeat: no-repeat;
					background-size: 100%;
					background-position: 0 2/@r;
				}
				.icon_comefrom{
					display: inline-block;
					vertical-align: top;
					width: 14/@r;
					height: 20/@r;
					margin-right: 5/@r;
					margin-left: 10/@r;
					background-image: url('../source/img/icon_zb.svg');
					background-repeat: no-repeat;
					background-size: 100%;
					background-position: 0 2/@r;
				}
			}
			.job{
				line-height: 20/@r;
				height: 20/@r;
				color: #666;
				.icon_job{
					display: inline-block;
					vertical-align: top;
					width: 14/@r;
					height: 20/@r;
					margin-right: 5/@r;
					background-image: url('../source/img/icon_bumen.svg');
					background-repeat: no-repeat;
					background-size: 100%;
					background-position: 0 2/@r;
				}
			}
			.label{
				line-height: 20/@r;
				height: 20/@r;
				color: #666;
				.icon_label{
					display: inline-block;
					vertical-align: top;
					width: 14/@r;
					height: 20/@r;
					margin-right: 5/@r;
					background-image: url('../source/img/icon_aihao.svg');
					background-repeat: no-repeat;
					background-size: 100%;
					background-position: 0 2/@r;
				}
				.label_item{
					margin-right: 4/@r;
				}
			}
		}
	}
	.desc{
		margin-top: 10/@r;
		width: 100%;
		text-align: center;
		background-color: #fff;
		margin-bottom: 18/@r;
		padding: 15/@r 15/@r 0 15/@r;
		box-sizing: border-box;
		.text{
			width: 100%;
			height: 100%;
			text-align: justify;
			line-height: 1.4;
			color: #666;
		}
		.height{
			height: 200%;
		}
	}
	.picWrap{
		width: 100%;
		box-sizing: border-box;
		text-align: center;
		background-color: #f6f9f9;
		padding: 15/@r 15/@r 15/@r 15/@r;
		.img_box{
			width: 100%;
			height: 200/@r;
			.img_lf{
				width: 136/@r;
				height: 200/@r;
				overflow: hidden;
				float: left;
			}
			.img_rf{
				float: left;
				width: 209/@r;
				height: 200/@r;
				.img_wrap{
					width: 96/@r;
					height: 96/@r;
					margin-bottom: 8/@r;
					margin-left: 8/@r;
					margin-top: 0;
					overflow: hidden;
					float: left;
				}
			}
		}
	}
	.rating_wrap{
		.rating_title{
			height: 38/@r;
			line-height: 38/@r;
			padding: 0 15/@r;
			color: #222;
			border-bottom: 1px solid #F0F0F0;
			border-top: 1px solid #F0F0F0;
		}
		.noRating{
			height: 80/@r;
			padding: 40/@r 0 130/@r;
			background: url('../source/img/icon_no_comment.svg') 50% 40/@r no-repeat;
			background-size: 55/@r;
			text-align: center;
			line-height: 130/@r;
			color: #999;
		}
		.ratings{
			padding-bottom: 104/@r;
			.rating{
				padding: 15/@r 15/@r 0;
				display: flex;
				.rating_avatar{
					font-size: 0;
					flex: 0 0 28/@r;
					height: 28/@r;
					border-radius: 50%;
					overflow: hidden;
				}
				.rating_text{
					flex: 1;
					padding-left: 8/@r;
					padding-bottom: 15/@r;
					border-bottom: 1px solid #F0F0F0;
					.rating_name{
						height: 22/@r;
						line-height: 22/@r;
						color: #222;
					}
					.rating_content{
						width: 300/@r;
						box-sizing: border-box;
						word-wrap: break-word;
						line-height: 20/@r;
						margin-top: 10/@r;
					}
				}
			}
		}
	}
	.send_wrap{
		width: 100%;
		height: 74/@r;
		padding: 15/@r 87/@r;
		box-sizing: border-box;
		position: fixed;
		bottom: 0;
		.send{
			width: 100%;
			height: 100%;
			margin: 0 auto;
			line-height: 44/@r;
			text-align: center;
			background-image: linear-gradient(90deg, #FFCA3D 0%, #FF5E3B 100%);
			box-shadow: 0 4/@r 3/@r 0 rgba(255,94,47,0.50);
			color: #fff;
		} 
	}
	.rating_box{
		position: fixed;
		bottom: 0;
		left: 0;
		width: 100%;
		background: #FFFFFF;
		box-shadow: 0 -1px 2px 0 rgba(0,0,0,0.10);
		.quick_rating{
			padding: 14/@r 0 7/@r 15/@r;
			height: 55/@r;
			font-size: 0;
			box-sizing: border-box;
			.quick_text1{
				display: inline-block;
				width: 107/@r;
				height: 34/@r;
				border-radius: 18/@r;
				background: #FFFFFF;
				border: 1px solid #FF5E3B;
				box-shadow: 0 2px 4px 0 rgba(255,94,47,0.20);
				line-height: 34/@r;
				text-align: center;
				color: #FF5E3B;
				margin-right: 10/@r;
				&:last-child{
					margin-right: 0;
				}
			}
		}
		.rating_input{
			height: 48/@r;
			padding: 9/@r 15/@r;
			box-sizing: border-box;
			font-size: 0;
			.input{
				display: inline-block;
				line-height: 30/@r;
				box-sizing: border-box;
				width: 288/@r;
				height: 32/@r;
				background: #EEEEEE;
				border-radius: 4px;
				text-indent: 1em;
			}
			.send_rating{
				padding: 11/@r 20/@r;
				color: #FF5E3B;
			}
		}
	}
	.loading{
		position: fixed;
		top: 0;
		left: 0;
		bottom: 80/@r;
		right: 0;
		
		.loading_wrap{
			position: absolute;
			top: 55%;
			left: 50%;
			width: 60/@r;
			height: 60/@r;
			margin-left: -30/@r;
			margin-top: -30/@r;
			background-image: url('../source/img/loading.svg');
			background-size: 100%;
			border-radius: 8/@r;
			overflow: hidden;
			opacity: 0.8;
			background-color: #222;
		}
	}
}
</style>
