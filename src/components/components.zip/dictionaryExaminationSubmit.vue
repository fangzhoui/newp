<template>
	<div class="examination">
		<ul class="question_list">
			<li class="question_wrap" v-for="(item, index) in moduleList" :class="{'card1': index == showClickItem, 'card2': index == showClickItem+1, 'fide': item.show}">
				<div class="titleItem_text fontSize_18">{{item.Question}}</div>
				<div class="option" v-for="(option, index1) in item.Options" :class="{'false': index1 + 1 == item.staffAnswer, 'true': index1 + 1 == item.Answer}">
					<span class="optionA fontSize_20">{{ index1 | optionA }}</span>
					<span class="option_text fontSize_16">{{ option.Content }}</span>
				</div>
			</li>
		</ul>
		<div class="next_wrap">
			<span class="prev fontSize_16" :class="{'prohibit': showClickItem == 0}" @click="prev">上一题</span>
			<span class="prev next fontSize_16" :class="{'last': showClickItem == moduleList.length-1}" @click="next($event)">{{text}}</span>
		</div>
	</div>
</template>

<script>
export default {
	name: 'examinationSubmit',
	props: {
		moduleList: {
			type: Array
		},
		clickItem: {
			type: Number,
			default: 0
		}
	},
	data(){
		return{
			text: '下一题',
			choiceList: [],
			nosendchoiceItem: null,
			showClickItem: 0,
		}
	},
	created(){
		this.load();
		this.showClickItem = this.clickItem;
		if(this.showClickItem == this.moduleList.length - 1){
			this.text = '返回';
		}
		this.moduleList.forEach((item)=>{
			item.show = false;
		});
	},
	watch: {
        "$route": "load",
    },
	methods: {
		load: function(){
            this.iosReturn();
        },
		iosReturn(){
			let _self = this;
			dd.biz.navigation.setLeft({
				show: true,//控制按钮显示， true 显示， false 隐藏， 默认true
				control: true,//是否控制点击事件，true 控制，false 不控制， 默认false
				showIcon: true,//是否显示icon，true 显示， false 不显示，默认true； 注：具体UI以客户端为准
				text: '返回',//控制显示文本，空字符串表示显示默认文本
				onSuccess : function(result) {
					_self.$router.push({path: '/dictionary/submitPage', query: {part: 'submitPage'}});
				},
				onFail : function(err) {}
			});
		},
		prev(){
			if(this.showClickItem >= 1){
				this.showClickItem--;
				this.moduleList[this.showClickItem].show = false;
				if(this.showClickItem == this.moduleList.length - 2){
					this.text = '下一题';
				}
			}
		},
		next(event){
			if(this.showClickItem < this.moduleList.length - 1){
				this.showClickItem++;
				this.moduleList[this.showClickItem-1].show = true;
				if(this.showClickItem == this.moduleList.length - 1){
					this.text = '返回';
				}
			}
			let obj = event.target;
			if(obj.innerHTML == '返回'){
				this.$router.push({path: '/dictionary/submitPage', query: {part: 'submitPage'}});
			}
		}
	},
	filters: {
		optionA(data){
			if(data == 0){
				return 'A'
			}else if(data == 1){
				return 'B'
			}else if(data == 2){
				return 'C'
			}
		}
	},
	components: {
	}
}
</script>

<style rel="stylesheet/less" lang="less" scoped>
@r:37.5rem;
.examination{
	position: absolute;
	top: 0;
	left: 0;
	bottom: 0;
	width: 100%;
	box-sizing: border-box;
	background: #F6F9F9;
	padding-top: 20/@r;
	.question_list{
		position: relative;
		width: 100%;
		height: 100%;
		transform: translate3d();
		.question_wrap{
			position: absolute;
			left: 0;
			top: 0;
			width: 100%;
			height: 100%;
			padding-bottom: 72/@r;
			background: #F6F9F9;
			display: none;
			transition: all ease .5s;
			.titleItem_text{
				width: 100%;
				padding: 25/@r 15/@r 20/@r;
				margin-bottom: 20/@r;
				box-sizing: border-box;
				background: #FFFFFF;
				border: 1px solid #F0F0F0;
				box-shadow: 0 0 14px 0 rgba(0,0,0,0.10);
				line-height: 22/@r;
				&:before{
					content: '单选题';
					font-size: 14px;
					color: #fff;
					text-align: center;
					line-height: 22/@r;
					display: block;
					position: absolute;
					top: -11/@r;
					left: 0;
					width: 77/@r;
					height: 22/@r;
					background: #1B4551;
					box-shadow: 0 2px 4px 0 rgba(27,69,81,0.30);
					border-radius: 0 11/@r 11/@r 0;
				}
			}
			.option{
				position: relative;
				width: 345/@r;
				padding: 20/@r 40/@r 20/@r 20/@r;
				box-sizing: border-box;
				background: #FFFFFF;
				border: 5px solid #F0F0F0;
				border-radius: 4px;
				margin: 0 auto 10/@r;
				display: flex;
				.optionA{
					flex: 0 0 14/@r;
					line-height: 28/@r;
					padding-right: 20/@r;
					box-sizing: border-box;
				}
				.option_text{
					flex: 1;
					line-height: 22/@r;
					box-sizing: border-box;
				}
			}
			.false{
				border: 5px solid #1B4551;
				box-shadow: 0 2px 4px 0 rgba(27,69,81,0.30);
				background-image: url('../source/img/icon_answer_error.svg');
				background-size: 20/@r 20/@r;
				background-repeat: no-repeat;
				background-position: 97% 50%;
			}
			.true{
				border: 5px solid #66BD5C;
				box-shadow: 0 2px 4px 0 rgba(27,69,81,0.30);
				background-image: url('../source/img/icon_answer_right.svg');
				background-size: 20/@r 20/@r;
				background-repeat: no-repeat;
				background-position: 97% 50%;
			}
		}
		.card1{
			display: block;
			transform: scale(1);
			z-index: 10;
			opacity: 1;
		}
		.card2{
			display: block;
			transform: scale(0.7);
			z-index: 1;
			opacity: 0;
		}
		.fide{
			z-index: 20;
			display: block;
			opacity: 1;
			transition: all ease 1.4s;
			transform: translate(-500%, 0);
		}
	}
	.next_wrap{
		position: fixed;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 72/@r;
		background: #fff;
		padding: 14/@r 20/@r;
		box-shadow: 0 -1px 2px 0 rgba(0,0,0,0.10);
		box-sizing: border-box;
		z-index: 999;
		.prev{
			display: inline-block;
			width: 154/@r;
			height: 44/@r;
			border: 3px solid #1B4551;
			border-radius: 43/@r;
			box-sizing: border-box;
			line-height: 38/@r;
			text-align: center;
			color: #1B4551;
		}
		.next{
			margin-left: 26/@r;
			background: #1B4551;
			color: #fff;
		}
		.prohibit{
			border: 3px solid #999;
			color: #999;
		}
		.last{
			border: 3px solid #FF5E3B;
			background: #FF5E3B;
		}
	}
}
</style>
