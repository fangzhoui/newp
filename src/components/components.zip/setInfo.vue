<template>
	<div class="setInfo" :style="{height: height+'px'}">
		<div class="wrap" v-show="pageRouterDisplay == 1">
			<div class="new1">
				<div class="bg_fff"></div>
				<div class="avatar">
					<div class="pic_wrap">
						<img :src="user.FaceUrl">
					</div>
					<p class="name fontSize_18">{{user.EmployeeName}}</p>
				</div>
				<div class="sex">
					<div class="sex_item" :class="{'active': user.Sex==1}" @click="user.Sex=1">
						<i class="iconfont fontSize_40">&#xe60d</i>
						<span class="sex_text fontSize_12">男士</span>
					</div>
					<div class="sex_item" :class="{'active1': user.Sex==0}" @click="user.Sex=0">
						<i class="iconfont fontSize_38">&#xe60e</i>
						<span class="sex_text fontSize_12">女士</span>
					</div>
				</div>
				<div class="birthday_wrap">
					<div class="title">选择生日</div>
					<div class="birthday" @click="setBir">
						{{user.Birthday}}
					</div>
					<div class="line"></div>
				</div>
			</div>
			<div class="next">
				<div class="btn" @click="setSexAndBir">下一步</div>
			</div>
		</div>
		<div class="wrap" v-show="pageRouterDisplay == 2">
			<div class="new2">
				<p class="msg fontSize_30">
					想要混脸熟?<br> 来张<span class="yellow">自拍照</span>吧！
				</p>
				<div class="pic_wrap">
					<div class="canmer">
						<img :src="user.Url" id="img" ref='upload'>
						<input type="file" accept="image/png,image/jpg,image/jpeg" id="upfile" @change="change($event)" >
						<label class="labelupfile" for="upfile"></label>
					</div>
				</div>
			</div>
			<div class="next">
				<div class="btn" @click="setUrl">下一步</div>
			</div>
		</div>
		<div class="wrap" v-show="pageRouterDisplay == 3">
			<div class="new3">
				<p class="msg fontSize_26">认真填写，惊喜意想不到！</p>
				<div class="job_wrap">
					<input type="text" class="job fontSize_16" v-model="user.Post" maxlength="10"  placeholder="输入部门+岗位">
				</div>
				<div class="city_wrap">
					<div class="city fontSize_16" @click="changeCity" :class="{'active': user.Province}"><span v-show="!user.Province">选择自己的家乡</span><span v-show="user.Province">{{user.Province}}<span v-show="user.Province!=user.City">-{{user.City}}</span></span></div>
				</div>
				<textarea class="desc fontSize_14" rows="5" maxlength="95" v-model="user.Description" placeholder="和大家打个招呼，说说工作经历或者对未来的美好憧憬"></textarea>
			</div>
			<div class="next">
				<div class="btn" @click="setDes">下一步</div>
			</div>
		</div>
		<div class="wrap" v-show="pageRouterDisplay == 4">
			<div class="new4">
				<div class="wrap_label">
					<v-newpeople :chooseLabel='chooseLabel' ref="chooseLabel"></v-newpeople>
				</div>
				<div class="next">
					<div class="btn" @click="setHobby">下一步</div>
				</div>
			</div>
		</div>
		<div class="wrap" v-show="pageRouterDisplay == 5" v-if="!user.Pushed">
			<div class="new5">
				<p class="msg fontSize_20">
					同事合影完，别忘了Ta的名字哦！
				</p>
				<ul class="image_list">
					<li class="image_item" v-for="(item,index) in picData">
						<div class="camer" ref="pic" @click="addImg(index)"><img :src="item.PicUrl" v-show="item.PicUrl != ''" width="100%"
						height="100%"></div>
						<div class="name fontSize_14" :class="{'active': item.EmployeeName != 'Ta的名字'}" @click="addName(index)">{{item.EmployeeName}}</div>
					</li>
				</ul>
			</div>
			<div class="next">
				<div class="btn" @click="gotoCard">下一步</div>
			</div>
		</div>
	</div>
</template>
<script>
import newpeople from './hobby_select';
import {$loadImage} from '@/utils/loadImage.js';
import Exif from 'exif-js';
export default {
	name: 'setInfo',
	props: {
		user: {
			type: Object
		},
		userConfig: {
			type: Object
		}
	},
	data () {
		return {
			pageRouterDisplay: 1,
			height: 0,
			pro: [],
			city: [],
			chooseLabel: [],
			picData: [{PicUrl: '', EmployeeName: 'Ta的名字', GroupPhotoId: ''}, {PicUrl: '', EmployeeName: 'Ta的名字', GroupPhotoId: ''}, {PicUrl: '', EmployeeName: 'Ta的名字', GroupPhotoId: ''}, {PicUrl: '', EmployeeName: 'Ta的名字', GroupPhotoId: ''}, {PicUrl: '', EmployeeName: 'Ta的名字', GroupPhotoId: ''}],
		}
	},
	created(){
		this.setRight();
		this.$http.get('/newtask/provinceList').then((response) => {
			response = response.body;
			this.pro = response.list;
			this.pro.forEach((item) => {
				let o = item
				for(var key in o){
					if(key === 'ProvinceId'){
						o['value'] = o['ProvinceId']
						delete(o[key])
					}
					if(key === 'ProvinceName'){
						o['key'] = o['ProvinceName']
						delete(o[key])
					}
				}
			})
		});
		this.$http.get('/newtask/review').then((response) => {
			response = response.data.list
			response.forEach((item) => {
				let index = item.GroupPhotoId - 1
				this.picData.splice(index, 1 , item)

				if(item.EmployeeName == ''){
					item.EmployeeName = 'Ta的名字'
				}
			})
			this.$nextTick( () => {
				if (this.user.Url) {
					this.$refs.upload.src = this.user.Url;
				}
				for (var i = 0; i < this.picData.length; i++) {
					if (this.picData[i].PicUrl) {
						$loadImage(this.picData[i].PicUrl,this.$refs.pic[i]);
					}
				}
			});
		});
	},
	mounted(){
		this.height = document.body.clientHeight;
		this.chooseLabel = this.user.hobbies;
		this.$refs.chooseLabel.load();
		this.load();
	},
	watch: {
		"$route": "load",
	},
	methods: {
		load(){
			this.pageRouterDisplay = this.$route.query.page || 3;
			this.setLeft();
			let title = 0;
			if (this.user.Pushed) {
				title = this.pageRouterDisplay + "/4";
			} else {
				title = this.pageRouterDisplay + "/5";
			}
			dd.biz.navigation.setTitle({
				title : title,
			});
		},
		setLeft(){
			var self = this;
			if (this.pageRouterDisplay == 1) {
				dd.biz.navigation.setLeft({
					show: true,
					control: true,
					text: "返回",
					onSuccess : function(result) {
						dd.biz.navigation.close({});
					},
					onFail : function(err) {}
				});
			} else {
				dd.biz.navigation.setLeft({
					show: true,
					control: true,
					text: "上一步",
					onSuccess : function(result) {
						let page = self.pageRouterDisplay;
						page--;
						self.$router.push({path: '/setInfo',query:{page: page}});
					},
					onFail : function(err) {}
				});
			}
		},
		setRight(){
			dd.biz.navigation.setRight({
				show: false,
				control: true,
			});
		},
		setBir(){
			let _self = this;
			let myDate = new Date();
			if(this.user.Birthday == '-年-月-日') {
				dd.biz.util.datepicker({
					format: 'yyyy-MM-dd',
					value: myDate, //默认显示日期
					onSuccess: function(result) {
						_self.user.Birthday = result.value
					},
					onFail : function(err) {
					}
				})
			}else{
				dd.biz.util.datepicker({
					format: 'yyyy-MM-dd',
					value: _self.user.Birthday, //默认显示日期
					onSuccess: function(result) {
						_self.user.Birthday = result.value
					},
					onFail : function(err) {
					}
				})
			}
		},
		setSexAndBir(){
			let sex = this.user.Sex;
			let bir = this.user.Birthday;
			if(sex == 3 || bir === '-年-月-日'){
				dd.device.notification.alert({
					message: "请填写信息",
					title: "提示",//可传空
					buttonName: "好的",
					onSuccess : function() {
						//onSuccess将在点击button之后回调
						/*回调*/
					},
					onFail : function(err) {}
				});
			}else{
				this.$http.post('/newtask/infoSetting',{sex: sex, birthday: bir},{emulateJSON: true}).then((response) => {
					response = response.body;
					if(response.success){
						this.$http.post('/newtask/page', {page: 2},{emulateJSON: true}).then((response1) => {
							response1 = response1.body;
							if(response1.success){
								this.$router.push({path: '/setInfo',query:{page: 2}});
							}else{
								alert(response1.error_msg);
							}
						});
					}else{
						alert(response.error_msg);
					}
				});
			}
		},
		change(event) {
			let self = this;
			this.clip(event, {
				aspectRatio: 4 / 3
			});
			this.uploadCallback = function(result){
				self.user.Url = result;
				self.$refs.upload.style.display = "block";
				self.$refs.upload.src = result;
			}
		},
		setUrl(){
			let empurl = this.$refs.upload.src;
			if(!empurl){
				dd.device.notification.alert({
					message: "请上传自拍照",
					title: "提示",
					buttonName: "好的",
				});
			}else{
				this.$http.post('/newtask/page', {page: 3},{emulateJSON: true}).then((response) => {
					response = response.body;
					if(response.success){
						this.$router.push({path: '/setInfo',query:{page: 3}});
					}else{
						alert(response.error_msg);
					}
				})
				
			}
		},
		changeCity(){
			let _self = this;
			let provinceId;
			let CityId;
			dd.biz.util.chosen({
				source: this.pro,
				onSuccess : function(result) {
					_self.user.Province = result.key;
					_self.user.ProvinceId = result.value;
					provinceId = _self.user.ProvinceId;
					_self.user.City = "";
					_self.user.CityId = "";
					_self.$http.get('/newtask/cityList',{params:{provinceId: provinceId}}).then((response) => {
						response = response.body
						let pro = response.list
						pro.forEach((item) => {
							let o = item
							for(var key in o){
								if(key === 'CityId'){
									o['value'] = o['CityId']
									delete(o[key])
								}
								if(key === 'CityName'){
									o['key'] = o['CityName']
									delete(o[key])
								}
							}
						})
						dd.biz.util.chosen({
							source: pro,
							onSuccess : function(result) {
								_self.user.City = result.key
								_self.user.CityId = result.value
								CityId = result.value
								provinceId = _self.user.ProvinceId
								_self.$http.post('/newtask/infoSetting', {province: provinceId, city: CityId},{emulateJSON: true}).then((response) => {
								})
							},
						   onFail : function(err) {}
						})
					})
				},
			   onFail : function(err) {}
			})
		},
		setDes(){
			let desc = this.user.Description;
			let province = this.user.Province;
			let city = this.user.City;
			let job = this.user.Post;
			if(typeof desc == 'object' || province == '' || city == '' || job == ''){
				dd.device.notification.alert({
					message: "请填写信息",
					title: "提示",
					buttonName: "好的",
				});
			}else{
				let desc = this.user.Description.toString();
				let provinceId = this.user.ProvinceId.toString();
				let cityId = this.user.CityId.toString();
				let job = this.user.Post.toString();
				this.$http.post('/newtask/infoSetting', {province: provinceId, city: cityId, description: desc, post: job},{emulateJSON: true}).then((response) => {});
				this.$http.post('/newtask/page', {page: 4},{emulateJSON: true}).then((response) => {
					response = response.body;
					if(response.success){
						this.$router.push({path: '/setInfo',query:{page: 4}});
					}else{
						alert(response.error_msg);
					}
				});
			}
		},
		setHobby(){
			let chooseLabel = [];
			for (var i = 0; i < this.chooseLabel.length; i++) {
				chooseLabel.push(this.chooseLabel[i].Id);
			}
			if(chooseLabel.length <= 1){
				dd.device.notification.alert({
					message: "请选择2至6个兴趣爱好",
					title: "提示",//可传空
					buttonName: "好的",
					onSuccess : function() {

					},
					onFail : function(err) {}
				});
			}else{
				chooseLabel = JSON.stringify(chooseLabel);
				this.$http.post('/newtask/addHobby',{Ids: chooseLabel},{emulateJSON: true}).then((response) => {

				});
				if(this.user.Pushed){
					this.$http.post('/newtask/page', {page: 6},{emulateJSON: true}).then((response) => {
						response = response.body;
						if(response.success){
							this.$router.push({ path: '/card' })
						}else{
							alert(response.error_msg);
						}
					})
					
				} else {
					this.$http.post('/newtask/page', {page: 5},{emulateJSON: true}).then((response) => {
						response = response.body;
						if(response.success){
							this.$router.push({path: '/setInfo',query:{page: 5}});
						}else{
							alert(response.error_msg);
						}
					});
				}
			}
		},
		addImg(index){
			let _self = this;
			dd.biz.util.uploadImage({
				multiple: false,
				max: 1,
				onSuccess : function(result) {
					let url = result.toString()
					let id = (index+1).toString()
					let questDataId = _self.user.questDataId.toString()
					_self.$http.post('/newtask/uploadImage',{picUrl: url, groupPhotoId: id, questDataId: questDataId}, {emulateJSON: true}).then((response) => {
						response = response.body;
						if (response.success) {
							_self.picData[index].PicUrl = result;
							_self.$nextTick( () => {
								_self.$refs.pic[index].innerHTML = "";
								$loadImage(_self.picData[index].PicUrl,_self.$refs.pic[index]);
							});
						}
					})
				},
				onFail : function(err) {
				}
			})
		},
		addName(index){
			let _self = this
			let _index = index
			if(this.picData[index].PicUrl == ''){
				dd.device.notification.alert({
					message: "请先传照片",
					title: "提示",//可传空
					buttonName: "好的",
					onSuccess : function() {
						//onSuccess将在点击button之后回调
						/*回调*/
					},
					onFail : function(err) {}
				});
				return
			}
			dd.biz.contact.choose({
				startWithDepartmentId: 0, //-1表示打开的通讯录从自己所在部门开始展示, 0表示从企业最上层开始，(其他数字表示从该部门开始:暂时不支持)
				multiple: false, //是否多选： true多选 false单选； 默认true
				corpId: _self.userConfig.openId, //企业id
				isNeedSearch: true, // 是否需要搜索功能
				title : "选择和你合影的他", // 如果你需要修改选人页面的title，可以在这里赋值 
				onSuccess: function(data) {
					let id = (index+1).toString()
					let questDataId = _self.user.questDataId.toString()
					let userId = data[0].emplId.toString()
					_self.$http.post('/newtask/empbind',{userId: userId, groupPhotoId: id}, {emulateJSON: true}).then((response) => {
						if(!response.body.success){
							_self.picData[_index].EmployeeName = 'Ta的名字'
							dd.device.notification.alert({
								message: response.body.error_msg,
								title: "提示",//可传空
								buttonName: "好的",
								onSuccess : function() {
								},
								onFail : function(err) {}
							});
						} else {
							_self.picData[_index].EmployeeName = data[0].name
						}
					})
				},
				onFail : function(err) {

				}
			});
		},
		gotoCard(){
			for (var i = 0; i < this.picData.length; i++){
				if(this.picData[i].EmployeeName == 'Ta的名字'){
					dd.device.notification.alert({
						message: "请填写完整",
						title: "提示",
						buttonName: "好的",
					});
					return false;
					break;
				}
			}
			this.$http.post('/newtask/page', {page: 6},{emulateJSON: true}).then((response) => {
				response = response.body;
				if(response.success){
					this.$router.push({ path: '/card' })
				}else{
					alert(response.error_msg);
				}
			})
			
		}
	},
	components: {
		"v-newpeople": newpeople
	}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style rel="stylesheet/less" lang="less" scoped>
@import '../source/css/cliper.css';
@r:37.5rem;
.wrap{
	position: relative;
	top: 0;
	bottom: 0;
	width: 100%;
	height: 100%;
}
.new1{
	position: absolute;
	top: 0;
	bottom: 93/@r;
	width: 100%;
	background: url('../source/img/im_cloud.svg') left bottom no-repeat,
				linear-gradient(-180deg, #FFFFFF 0%, #FFFFFF 100%) center bottom no-repeat,
				linear-gradient(-180deg, #FFCA78 0%, #EE7074 100%) no-repeat;
	background-size: 100%,80% 90%,100% 99%;
	.bg_fff{
		position: absolute;
		width: 90%;
		left: 5%;
		top: 70/@r;
		bottom: 0;
	}
	.avatar{
		position: absolute;
		left: 50%;
		top: 99/@r;
		margin-left: -35/@r;
		text-align: center;
		.pic_wrap{
			width: 70/@r;
			height: 70/@r;
			border-radius: 50%;
			overflow: hidden;
			padding: 3/@r;
			background-color: rgb(240, 240, 240);
			img{
				width: 70/@r;
				height: 70/@r;
				border-radius: 50%;
			}
		}   
		.name{
			margin-top: 15/@r;
			color: #222222;
			letter-spacing: 0;
			line-height: 18/@r;
			font-weight: 700;
		}
	}
	.sex{
		position: absolute;
		top: 249/@r;
		left: 50%;
		width: 146/@r;
		font-size: 0;
		margin-left: -73/@r;
		.sex_item{
			float: left;
			width: 40/@r;
			text-align: center;
			color: #C7C7C7;
			i{
				font-size: 40/@r;
			}
			.sex_text{
				letter-spacing: 0;
				display: block;
				padding-top: 4/@r;
			}
		}
		.sex_item:nth-child(2){
			float: right;
		}
		.active{
			color: #008CEE;
			i{
				text-shadow: 2/@r 2/@r 2/@r #B4E0FF;
			}
			span{
				text-shadow: 2/@r 2/@r 2/@r #B4E0FF;
			}
		}
		.active1{
			color: #FF5E3B;
			i{
				text-shadow: 2/@r 2/@r 2/@r #FFC3B5;
			}
			span{
				text-shadow: 2/@r 2/@r 2/@r #FFC3B5;
			}
		}
	}
	.birthday_wrap{
		position: absolute;
		top: 385/@r;
		width: 100%;
		text-align: center;
		.title{
			font-size: 15/@r;
			line-height: 21/@r;
			color: #666666;
			letter-spacing: 0;
		}
		.birthday{
			font-size: 18/@r;
			line-height: 25/@r;
			color: #FF5E3B;
			letter-spacing: 0;
			padding-top: 12/@r;
			font-weight: 700;
		}
		.line{
			width: 94/@r;
			height: 4/@r;
			background: #FFCA3D;
			margin: 0 auto;
			margin-top: 3/@r;
			
		}
	}
}
.new2 {
	position: absolute;
	top: 0;
	bottom: 93/@r;
	width: 100%;
	overflow: hidden;
	background: url('../source/img/im_cloud.svg') left bottom no-repeat,
	url('../source/img/im_fly.png') 45/@r 120/@r no-repeat,
	linear-gradient(-180deg, #EEAD92 0%, #6018DC 100%) no-repeat;
	background-size: 100%, 33%, 100% 99%;
	.msg {
		position: absolute;
		top: 30/@r;
		left: 30/@r;
		color: #fff;
		text-shadow: 5px 2px 6px #8F7221;
		line-height: 1.2;
		.yellow {
			color: #FFD155;
		}
	}
	.pic_wrap {
		position: absolute;
		top: 154/@r;
		width: 339/@r;
		height: 258/@r;
		padding: 8/@r;
		left: 50%;
		transform: translateX(-50%);
		box-sizing: border-box;
		background: #FFDFD9;
		.canmer {
			position: relative;
			width: 323/@r;
			height: 242/@r;
			background-color: #fff;
			text-align: center;
			overflow: hidden;
			background-image: url('../source/img/lxr_camer.svg');
			background-size: 30% 30%;
			background-position: 50% 50%;
			background-repeat: no-repeat;
			.labelupfile{
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				display: block;
				z-index: 9;
			}
			#upfile{
				display: none;
			}
			#img{
				width: 100%;
			}
		}
	}
}
.new3{
	position: absolute;
	top: 0;
	bottom: 93/@r;
	width: 100%;
	overflow: hidden;
	background: url('../source/img/im_cloud.svg') left bottom no-repeat,
	url('../source/img/lxr_bg_3.svg') 18/@r 90/@r no-repeat,
	linear-gradient(-180deg, #FFCA78 0%, #EE7074 100%) no-repeat;
	background-size: 100%, 90%, 100% 100%;
	.msg{
		position: absolute;
		top: 32/@r;
		left: 25/@r;
		color: #fff;
		text-shadow: 5px 2px 6px #8F7221;
		line-height: 1.1;
	}
	.desc{
		position: absolute;
		top: 300/@r;
		left: 43/@r;
		width: 290/@r;
		outline: none;
		resize: none;
		border: none;
		background-color: rgba(255, 255, 255, 0);
		line-height: 24/@r;
	}
	.job_wrap{
		position: absolute;
		top: 108/@r;
		left: 142/@r;
		width: 190/@r;
		height: 23/@r;
		line-height: 23/@r;
		font-size: 0;
		/*background-color: #000;*/
		.job{
			display: inline-block;
			width: 100%;
			height: 100%;
			color: #000;
			text-align: right;
			span{
				display: inline-block;
				width: 100%;
				height: 100%;
			}
		}
	}
	.city_wrap{
		position: absolute;
		top: 182/@r;
		left: 142/@r;
		width: 190/@r;
		height: 23/@r;
		line-height: 23/@r;
		text-align: right;
		font-size: 0;
		color: #C7C7C7;
		/*background-color: #000;*/
		.city{
			display: inline-block;
			width: 100%;
			height: 100%;
			color: #C7C7C7;
			span{
				display: inline-block;
				/*width: 100%;*/
				height: 100%;
			}
		}
		.active{
			color: #000;
		}
	}
}
.new4{
	position: absolute;
	top: 0;
	bottom: 0;
	width: 100%;
	height: 100%;
	.wrap_label{
		position: absolute;
		top: 0;
		bottom: 93/@r;
		width: 100%;
	}
}
.new5{
	position: absolute;
	width: 100%;
	top: 0;
	bottom: 93/@r;
	background: url('../source/img/im_cloud.svg') left bottom no-repeat,
				linear-gradient(-180deg, #FFCA78 0%, #EE7074 100%) no-repeat;
	background-size: 100%,100% 99%;
	
	.msg{
		position: absolute;
		top: 22/@r;
		left: 38/@r;
		color: #fff;
		text-shadow: 5px 2px 6px #8F7221;
		line-height: 1.2;
	}
	.image_list{
		position: absolute;
		top: 64/@r;
		width: 295/@r;
		left: 50%;
		transform: translateX(-50%);
		.image_item{
			width: 100%;
			height: 72/@r;
			margin-bottom: 10/@r;
			background-color: #fff;
			box-shadow: 0 2/@r 4/@r 0 rgba(102,102,102,0.20);
			border-radius: 4/@r;
			overflow: hidden;
			display: flex;
			.camer{
				box-sizing: border-box;
				flex: 0 0 72/@r;
				width: 72/@r;
				height: 100%;
				background-color: #f5f8f9;
				text-align: center;
				background-image: url('../source/images/lxr_camer.svg');
				background-size: 64/@r 64/@r;
				background-repeat: no-repeat;
				background-position: 4/@r 4/@r;
			}
			.name{
				flex: 1;
				height: 100%;
				background-color: #fff;
				line-height: 72/@r;
				text-align: center;
				color: #c9c9c9;
			}
			.active{
				color: #000;
			}
		}
	}
}
.next{
position: absolute;
left: 0;
bottom: 0;
width: 100%;
height: 93/@r;
background-color: #fff;
.btn{
	position: absolute;
	left: 50%;
	top: 50%;
	margin-top: -22/@r;
	margin-left: -101/@r;
	width: 202/@r;
	height: 44/@r;
	text-align: center;
	font-size: 16/@r;
	line-height: 44/@r;
	color: #FFFFFF;
	letter-spacing: 0;
	background-image: linear-gradient(90deg, #FFCA3D 0%, #FFA83C 31%, #FF673B 92%, #FF5E3B 100%);
	box-shadow: 0 4/@r 3/@r 0 rgba(255,94,47,0.50);
}
}
</style>
